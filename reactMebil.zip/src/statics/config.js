window.g = {
  AXIOS_TIMEOUT: 10000,
  ApiUrl: 'http://www.phonegap100.com/appapi.php?a=getPortalList&catid=20&page=', // 配置服务器地址,
  login:"http://192.168.2.123:8899/distributor/member/login",
  register:'http://192.168.2.123:8899/distributor/member/updatePass',
  mcMembers:'http://192.168.2.123:8899/distributor/mcMembers/findById',
  //stock购买
  stock:'http://192.168.2.123:8899/distributor/stock',
  NineLogin:"http://md.9knx.com:9099/sale/login",
    //  套餐
  meal:"http://192.168.2.123:8899/distributor/meal",
  mealDts:"http://192.168.2.123:8899/distributor/meal/findById?id=",
  ParentPage: {
    DeteailsApi:'http://www.phonegap100.com/appapi.php?a=getPortalArticle&aid=',
  },
}
