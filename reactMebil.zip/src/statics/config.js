window.g = {
  AXIOS_TIMEOUT: 10000,
  ApiUrl: 'http://www.phonegap100.com/appapi.php?a=getPortalList&catid=20&page=', // 配置服务器地址,
  LoginApi:'http://md.9knx.com:9099/sale/login',
    ParentPage: {
    DeteailsApi:'http://www.phonegap100.com/appapi.php?a=getPortalArticle&aid=',
  },
}
