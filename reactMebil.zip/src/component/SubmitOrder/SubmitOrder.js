import React,{ Component,Fragment } from "react";
class SubmitOrder extends Component{
    render(){
        return(
            <Fragment>

            </Fragment>
        )
    }
    componentDidMount(){
        document.title="提交订单"
    }
}
export default SubmitOrder;
